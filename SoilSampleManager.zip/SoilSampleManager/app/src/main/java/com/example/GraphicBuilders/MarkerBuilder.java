package com.example.GraphicBuilders;

public class MarkerBuilder {

    double longitude;
    double latitude;
    String uniqueMarkerId;

}
